1. make -> loescht scheinbar eeprom auch (alles FFFFF)
2. sh flashEEPROM.sh -> schreibt neue Werte in EEPROM

Moeglich, dass der Loop fuers eeprom nicht noetig ist,
da kein write zugriff stattfindet.

EEPROM bis zu 100.000 zu beschreiben -> FLASH nur 10.000 mal !!!!